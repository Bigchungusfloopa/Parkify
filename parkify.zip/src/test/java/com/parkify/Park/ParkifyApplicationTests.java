package com.parkify.Park;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkifyApplicationTests {

	@Test
	void contextLoads() {
	}

}

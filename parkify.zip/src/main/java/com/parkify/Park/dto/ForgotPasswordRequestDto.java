package com.parkify.Park.dto;
import lombok.Data;
@Data public class ForgotPasswordRequestDto { private String email; }
